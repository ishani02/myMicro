package com.example.identity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdentityServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
